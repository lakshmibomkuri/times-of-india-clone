"use client";

import { Header } from "@/components/toi/header";
import { Footer } from "@/components/toi/footer";
import { SharedAdStrips } from "@/components/toi/shared-ad-strips";
import { HotOnWebSection } from "@/components/toi/sections/hot-on-web-section";
import { TrendingTopicsSection } from "@/components/toi/sections/trending-topics-section";
import { PopularCategoriesSection } from "@/components/toi/sections/popular-categories-section";
import { TrendingVideosSection } from "@/components/toi/sections/trending-videos-section";
import Image from "next/image";
import Link from "next/link";
import { Play, ChevronRight, ChevronLeft } from "lucide-react";
import { useState } from "react";

const categories = ["Top Videos", "Trending", "Entertainment", "TOI Originals", "Sports", "Regional"];
const subCategories = ["Sports", "Cricket", "Featured", "Football", "Formula E"];

const topVideos = [
  { id: 1, title: "PM Modi Joins 10,000 Bodo Zumba Record Event In Bodoland", duration: "08:22", views: "351.5K", time: "12 hours ago", thumbnail: "https://picsum.photos/seed/vid1/400/225" },
  { id: 2, title: "500% Tariff Threat Over Russian Oil: US and Europe At Odds", duration: "05:05", views: "1.6K", time: "14 hours ago", thumbnail: "https://picsum.photos/seed/vid2/400/225" },
  { id: 3, title: "Vaishnaw Rules Out Trade Talks At WEF; Assures India's Engagement With Major Economies", duration: "09:00", views: "38K", time: "50 minutes ago", thumbnail: "https://picsum.photos/seed/vid3/400/225" },
  { id: 4, title: "Iran WARNS Trump's Attack On Khamenei Would Trigger JIHAD, Top General Says 'Will Chop Off...'", duration: "12:30", views: "716", time: "3 hours ago", thumbnail: "https://picsum.photos/seed/vid4/400/225" },
  { id: 5, title: "Putin SHOCKS Trump On Greenland. Iran & Venezuela Oil; Russia Goes All-Out Against US", duration: "09:32", views: "1.2K", time: "4 hours ago", thumbnail: "https://picsum.photos/seed/vid5/400/225" },
  { id: 6, title: "Israeli Settler Attacks Force Bedouin Families to Flee West Bank Village Near Jericho", duration: "03:29", views: "196", time: "3 hours ago", thumbnail: "https://picsum.photos/seed/vid6/400/225" },
];

const shorts = [
  { id: 1, title: "Football Icon Messi Visits Anant Ambani's Vantara", views: "2K", thumbnail: "https://picsum.photos/seed/short1/200/350" },
  { id: 2, title: "PM Modi Visits Ethiopian National Museum", views: "24K", thumbnail: "https://picsum.photos/seed/short2/200/350" },
  { id: 3, title: "PM Modi Arrives In Oman, Receives Ceremonial Welcome", views: "17K", thumbnail: "https://picsum.photos/seed/short3/200/350" },
  { id: 4, title: "Why Is Trump Betting Big On Asim Munir", views: "2K", thumbnail: "https://picsum.photos/seed/short4/200/350" },
  { id: 5, title: "SHINee's Key Halts All Activities After SHOCKING Revelation", views: "12K", thumbnail: "https://picsum.photos/seed/short5/200/350" },
  { id: 6, title: "SpongeBob SquarePants Immortalised At TCL Chinese Theatre", views: "3K", thumbnail: "https://picsum.photos/seed/short6/200/350" },
];

const sportsVideos = [
  { id: 1, title: "How Falcon Risers Hyderabad Cricket's Next Frontier", category: "Cricket", duration: "04:47", views: "5.3K", thumbnail: "https://picsum.photos/seed/sport1/400/225" },
  { id: 2, title: "Studying Design in London: Reality Check For Students", category: "Education", duration: "05:18", views: "13.2K", thumbnail: "https://picsum.photos/seed/sport2/400/225" },
  { id: 3, title: "This Is Why SAT Feels Hard - Expert Analysis", category: "Education", duration: "13:05", views: "3.8K", thumbnail: "https://picsum.photos/seed/sport3/400/225" },
  { id: 4, title: "How Safe Is A MacBook Air For Students", category: "Technology", duration: "03:03", views: "28.5K", thumbnail: "https://picsum.photos/seed/sport4/400/225" },
];

const technologyVideos = [
  { id: 1, title: "Microsoft Frees Up Satya Nadella - CEO's Big Leadership Shake Up", duration: "12:45", views: "45K", thumbnail: "https://picsum.photos/seed/tech1/400/225" },
  { id: 2, title: "Sony ULT Tower 9 - Unleash The Bass", duration: "08:30", views: "23K", thumbnail: "https://picsum.photos/seed/tech2/400/225" },
  { id: 3, title: "FastTrack AI Meet - Full Coverage", duration: "15:20", views: "18K", thumbnail: "https://picsum.photos/seed/tech3/400/225" },
  { id: 4, title: "MacBook Air Smart Speedy Super Light Review", duration: "10:15", views: "67K", thumbnail: "https://picsum.photos/seed/tech4/400/225" },
];

const trendingVideos = [
  { id: 1, title: "वाली बात बिल्कुल सही है", views: "156K", thumbnail: "https://picsum.photos/seed/trend1/200/120" },
  { id: 2, title: "हनुमान पूजा का सबसे शक्तिशाली समय", views: "89K", thumbnail: "https://picsum.photos/seed/trend2/200/120" },
  { id: 3, title: "समुद्रिक शास्त्र चेहरे के निशान बतायेंगे भविष्य", views: "45K", thumbnail: "https://picsum.photos/seed/trend3/200/120" },
  { id: 4, title: "Kashmiri Pandit Exodus Or Genocide", views: "234K", thumbnail: "https://picsum.photos/seed/trend4/200/120" },
  { id: 5, title: "शनि की दशा जीवन की उल्टी गिनती?", views: "78K", thumbnail: "https://picsum.photos/seed/trend5/200/120" },
];

const toiShorts = [
  { id: 1, title: "Mumbai International Airport Means For Canada", views: "12K", thumbnail: "https://picsum.photos/seed/toishort1/200/350" },
  { id: 2, title: "500 Protesters Dead, Khamenei Under Fire, Will Trump Invade Iran?", views: "89K", thumbnail: "https://picsum.photos/seed/toishort2/200/350" },
  { id: 3, title: "Killed, 10,000 Held: Iran On Edge Amid Loud Calls", views: "45K", thumbnail: "https://picsum.photos/seed/toishort3/200/350" },
  { id: 4, title: "Trump's Big Announcement For Greenlanders 'Shakes' NATO", views: "67K", thumbnail: "https://picsum.photos/seed/toishort4/200/350" },
  { id: 5, title: "दुर्गा कौन हैं? इस बीज मंत्र से माँ लक्ष्मी होंगी प्रसन्न", views: "34K", thumbnail: "https://picsum.photos/seed/toishort5/200/350" },
];

const internationalNews = [
  { id: 1, title: "Denmark Sends More Troops To Greenland, Blasts Trump - Crisis Tests NATO", duration: "09:45", views: "156K", thumbnail: "https://picsum.photos/seed/intl1/400/225" },
  { id: 2, title: "Forget Greenland, Now US Military Another Neighbouring Country Mexico's Big Confirmation", duration: "11:20", views: "89K", thumbnail: "https://picsum.photos/seed/intl2/400/225" },
  { id: 3, title: "Qatar To Kick Out American - Washington and Global Defense At Al Udeid", duration: "08:15", views: "67K", thumbnail: "https://picsum.photos/seed/intl3/400/225" },
  { id: 4, title: "'Happy Vassal Or Miserable Slave?': Belgian PM Blasts Trump's Tactics", duration: "06:30", views: "45K", thumbnail: "https://picsum.photos/seed/intl4/400/225" },
];

const bollywoodVideos = [
  { id: 1, title: "Neha Kakkar Breaks Silence: 'Not Sure I'll Return'", duration: "05:30", views: "234K", thumbnail: "https://picsum.photos/seed/bolly1/400/225" },
  { id: 2, title: "Vir Das Mocks Bollywood Budgets - What Really Happened To Salman's Sikandar", duration: "08:45", views: "189K", thumbnail: "https://picsum.photos/seed/bolly2/400/225" },
  { id: 3, title: "Akshay Kumar In Deadly Aujla Controversy Explodes - Midnight Juhu Car Chase", duration: "12:20", views: "156K", thumbnail: "https://picsum.photos/seed/bolly3/400/225" },
  { id: 4, title: "Priyanka On Plastic Surgery: My Film Catering Cost", duration: "07:15", views: "123K", thumbnail: "https://picsum.photos/seed/bolly4/400/225" },
];

const toiOriginals = [
  { id: 1, title: "Border 2 - Official Hindi Teaser Starring Sunny Varun Dhawan", duration: "02:45", views: "1.2M", thumbnail: "https://picsum.photos/seed/orig1/400/225" },
  { id: 2, title: "Sagwaan - Official Trailer Starring Himanshu Singh Rajawat", duration: "03:15", views: "567K", thumbnail: "https://picsum.photos/seed/orig2/400/225" },
  { id: 3, title: "Smart Killer MKhoj - Official Trailer", duration: "02:30", views: "345K", thumbnail: "https://picsum.photos/seed/orig3/400/225" },
  { id: 4, title: "Eisha Singh On Engagement Rumours With Avinash: 'It's Bullsh*t'", duration: "08:20", views: "234K", thumbnail: "https://picsum.photos/seed/orig4/400/225" },
];

const healthFitness = [
  { id: 1, title: "Life After 60: Why India's Seniors Are Choosing Community Living", duration: "15:30", views: "89K", thumbnail: "https://picsum.photos/seed/health1/400/225" },
  { id: 2, title: "Life After 60: How To Redefine Life Post-Retirement", duration: "12:45", views: "67K", thumbnail: "https://picsum.photos/seed/health2/400/225" },
  { id: 3, title: "Senior Living in India - Myths, Realities & Future of Purposeful Ageing", duration: "18:20", views: "45K", thumbnail: "https://picsum.photos/seed/health3/400/225" },
  { id: 4, title: "Early Signs of Myopia - Nearsightedness Facts Straight", duration: "08:15", views: "34K", thumbnail: "https://picsum.photos/seed/health4/400/225" },
];

const hollywoodVideos = [
  { id: 1, title: "Rising Beauty Influencer Dead After Nightmare Car Crash - Victim's Mother's Threat", duration: "09:30", views: "567K", thumbnail: "https://picsum.photos/seed/holly1/400/225" },
  { id: 2, title: "Melissa Gilbert Fears Jail: 'I'll Have Busfield's An' - Timothy Busfield In Danger", duration: "11:20", views: "234K", thumbnail: "https://picsum.photos/seed/holly2/400/225" },
];

const formulaEVideos = [
  { id: 1, title: "Formula E 2025-26 Championship Overview - Step Guide to lo", duration: "12:45", views: "89K", thumbnail: "https://picsum.photos/seed/fe1/400/225" },
  { id: 2, title: "Formula E 2025 Pre Conference - Get a Front-Row 2025-26", duration: "08:30", views: "67K", thumbnail: "https://picsum.photos/seed/fe2/400/225" },
  { id: 3, title: "São Paulo E-Prix Formula E Season Round Team Principals Press Conference", duration: "15:20", views: "45K", thumbnail: "https://picsum.photos/seed/fe3/400/225" },
  { id: 4, title: "2025 Sao Paulo E-Prix Full Race Highlights - Season Opener Drama", duration: "18:45", views: "156K", thumbnail: "https://picsum.photos/seed/fe4/400/225" },
];

const foodVideos = [
  { id: 1, title: "From South India to James Beard: Chef Vijay's Journey - Tasteful Triumph", duration: "12:30", views: "89K", thumbnail: "https://picsum.photos/seed/food1/400/225" },
];

const musicVideos = [
  { id: 1, title: "Border 2 Song - Ghar Kab Aaoge | Song Out Now", duration: "04:30", views: "2.3M", thumbnail: "https://picsum.photos/seed/music1/400/225" },
  { id: 2, title: "Mafia Aadat - Hindi Song", duration: "03:45", views: "1.8M", thumbnail: "https://picsum.photos/seed/music2/400/225" },
];

const regionalHindi = [
  { id: 1, title: "भड़के पूरोपीय देश - ग्रीनलैंड, कनाडा, वेनेजुएला.. ट्रंप के ऊपर", duration: "15:30", views: "234K", thumbnail: "https://picsum.photos/seed/hindi1/400/225" },
  { id: 2, title: "फ्रांसीसी बाइन पर 200% लेंगे बोर्ड ऑफ पी", duration: "08:45", views: "156K", thumbnail: "https://picsum.photos/seed/hindi2/400/225" },
];

const trendingTopics = ["Gadar 2", "Rob Reiner", "Messi", "Dhurandhar", "Hema Malini", "Rajinikanth", "Donald Trump", "Smriti Mandhana"];

export default function VideosPage() {
  const [activeCategory, setActiveCategory] = useState("Top Videos");
  const [activeSub, setActiveSub] = useState("Sports");

  const VideoCard = ({ video, size = "normal" }: { video: typeof topVideos[0], size?: "normal" | "small" }) => (
    <Link href={`/videos/${video.id}`} className="group">
      <div className={`relative ${size === "small" ? "aspect-[16/10]" : "aspect-video"} rounded overflow-hidden mb-2`}>
        <Image src={video.thumbnail || "/placeholder.svg"} alt={video.title} fill className="object-cover group-hover:scale-105 transition-transform" />
        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
          <div className="w-10 h-10 bg-red-600/90 rounded-full flex items-center justify-center">
            <Play className="w-4 h-4 text-white fill-white ml-0.5" />
          </div>
        </div>
        <div className="absolute bottom-1.5 right-1.5 bg-black/80 text-white text-[9px] px-1.5 py-0.5 rounded flex items-center gap-1">
          <Play className="w-2 h-2 fill-white" />
          {video.duration}
        </div>
        <div className="absolute top-1.5 left-1.5">
          <span className="bg-red-600 text-white text-[8px] px-1 py-0.5 rounded font-bold">TOI</span>
        </div>
      </div>
      <h3 className={`${size === "small" ? "text-[11px]" : "text-[12px]"} text-[#333] group-hover:text-red-600 line-clamp-2 mb-1 leading-tight`}>
        {video.title}
      </h3>
      <div className="flex items-center gap-2 text-[10px] text-gray-500">
        <span>{video.views} views</span>
        <span>|</span>
        <span>{video.time || "2 hours ago"}</span>
      </div>
    </Link>
  );

  const SectionHeader = ({ title, showArrow = true }: { title: string, showArrow?: boolean }) => (
    <div className="flex items-center justify-between mb-3">
      <h2 className="text-[15px] font-bold text-[#333] flex items-center gap-1">
        {title} {showArrow && <ChevronRight className="w-4 h-4" />}
      </h2>
      <Link href="#" className="text-red-600 text-[11px] hover:underline">See All</Link>
    </div>
  );

  return (
    <div className="min-h-screen bg-white overflow-x-hidden" style={{ fontFamily: 'Arial, Helvetica, sans-serif' }}>
      {/* Shared Ad Strips */}
      {/* <SharedAdStrips /> */}

      {/* Main Content Area */}
      <div className="xl:ml-[145px] xl:mr-[145px]">
      {/* Top Ad Banner - AU Bank */}
      <div className="w-full bg-gradient-to-r from-[#1a1a2e] to-[#2d2d44] py-2">
        <div className="max-w-[970px] mx-auto px-4">
          <div className="flex items-center justify-center gap-4 text-white">
            <span className="text-[11px]">Still not banking with</span>
            <span className="text-xl font-bold text-yellow-400">AU?</span>
            <div className="flex items-center gap-2">
              <span className="text-[10px]">Up to</span>
              <span className="text-2xl font-bold text-yellow-400">6.50%</span>
              <span className="text-[9px]">interest p.a. &<br/>Monthly Interest Payment</span>
            </div>
            <button className="bg-white text-[#1a1a2e] text-[10px] px-3 py-1.5 rounded font-semibold">Open Account</button>
            <span className="text-[8px] text-gray-400">T&C Apply</span>
          </div>
        </div>
      </div>

      <Header />
      
      <main className="bg-[#f8f8f8]">
        <div className="max-w-[1100px] mx-auto px-4 py-4">
          {/* Page Header with Categories */}
          <div className="flex items-center justify-between mb-3 bg-white p-2.5 rounded">
            <div className="flex items-center gap-2">
              {categories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setActiveCategory(cat)}
                  className={`px-3 py-1 text-[11px] rounded whitespace-nowrap transition-colors ${
                    activeCategory === cat ? "text-red-600 font-bold" : "text-gray-600 hover:text-red-600"
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          {/* Now Playing Banner */}
          <div className="bg-[#333] text-white px-3 py-1.5 mb-3 rounded flex items-center gap-2 overflow-hidden">
            <span className="text-[10px] font-bold text-red-500 flex-shrink-0">Now Playing</span>
            <div className="text-[11px] truncate">PM Modi Joins 10,000 Bodo Zumba Record Event</div>
          </div>

          <div className="flex gap-4">
            {/* Main Content */}
            <div className="flex-1">
              {/* Top Videos Section */}
              <section className="mb-5 bg-white p-3 rounded">
                <SectionHeader title="Top Videos" />
                
                {/* Sub Categories */}
                <div className="flex items-center gap-1 mb-3 border-b border-gray-100 pb-2">
                  {subCategories.map((cat) => (
                    <button
                      key={cat}
                      onClick={() => setActiveSub(cat)}
                      className={`px-2.5 py-1 text-[10px] rounded transition-colors ${
                        activeSub === cat ? "bg-red-600 text-white" : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                      }`}
                    >
                      {cat}
                    </button>
                  ))}
                </div>
                
                <div className="grid grid-cols-3 gap-3">
                  {topVideos.map((video) => (
                    <VideoCard key={video.id} video={video} />
                  ))}
                </div>
              </section>

              {/* Shorts Section */}
              <section className="mb-5 bg-white p-3 rounded">
                <div className="flex items-center justify-between mb-3">
                  <h2 className="text-[15px] font-bold text-[#333] flex items-center gap-2">
                    <span className="bg-gradient-to-r from-red-500 to-orange-500 text-white text-[9px] px-2 py-0.5 rounded font-bold">SHORTS</span>
                  </h2>
                </div>
                
                <div className="flex gap-2.5 overflow-x-auto pb-2 scrollbar-hide">
                  {shorts.map((short) => (
                    <Link key={short.id} href="#" className="flex-shrink-0 w-[130px] group">
                      <div className="relative aspect-[9/16] rounded-lg overflow-hidden mb-1.5">
                        <Image src={short.thumbnail || "/placeholder.svg"} alt={short.title} fill className="object-cover group-hover:scale-105 transition-transform" />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent" />
                        <div className="absolute top-2 left-2">
                          <span className="bg-gradient-to-r from-red-500 to-orange-500 text-white text-[8px] px-1.5 py-0.5 rounded font-bold">SHORT</span>
                        </div>
                        <div className="absolute bottom-2 left-2 right-2">
                          <p className="text-[10px] text-white font-medium line-clamp-2 leading-tight">{short.title}</p>
                          <span className="text-[9px] text-gray-300">{short.views} views</span>
                        </div>
                      </div>
                    </Link>
                  ))}
                </div>
              </section>

              {/* Education Section */}
              <section className="mb-5 bg-white p-3 rounded">
                <SectionHeader title="Education" />
                <div className="grid grid-cols-4 gap-2.5">
                  {sportsVideos.map((video) => (
                    <VideoCard key={video.id} video={video} size="small" />
                  ))}
                </div>
              </section>

              {/* Technology Section */}
              <section className="mb-5 bg-white p-3 rounded">
                <SectionHeader title="Technology" />
                <div className="grid grid-cols-4 gap-2.5">
                  {technologyVideos.map((video) => (
                    <VideoCard key={video.id} video={video} size="small" />
                  ))}
                </div>
              </section>

              {/* Trending Section */}
              <section className="mb-5 bg-white p-3 rounded">
                <SectionHeader title="Trending" />
                <div className="flex gap-2.5 overflow-x-auto pb-2 scrollbar-hide">
                  {trendingVideos.map((video) => (
                    <Link key={video.id} href="#" className="flex-shrink-0 w-[140px] group">
                      <div className="relative aspect-[4/3] rounded overflow-hidden mb-1.5">
                        <Image src={video.thumbnail || "/placeholder.svg"} alt={video.title} fill className="object-cover group-hover:scale-105 transition-transform" />
                      </div>
                      <p className="text-[10px] text-[#333] line-clamp-2 leading-tight group-hover:text-red-600">{video.title}</p>
                      <span className="text-[9px] text-gray-500">{video.views} views</span>
                    </Link>
                  ))}
                </div>
              </section>

              {/* TOI Shorts Section */}
              <section className="mb-5 bg-white p-3 rounded">
                <SectionHeader title="TOI Shorts" />
                <div className="flex gap-2.5 overflow-x-auto pb-2 scrollbar-hide">
                  {toiShorts.map((short) => (
                    <Link key={short.id} href="#" className="flex-shrink-0 w-[130px] group">
                      <div className="relative aspect-[9/16] rounded-lg overflow-hidden mb-1.5">
                        <Image src={short.thumbnail || "/placeholder.svg"} alt={short.title} fill className="object-cover group-hover:scale-105 transition-transform" />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent" />
                        <div className="absolute bottom-2 left-2 right-2">
                          <p className="text-[10px] text-white font-medium line-clamp-2 leading-tight">{short.title}</p>
                        </div>
                      </div>
                    </Link>
                  ))}
                </div>
              </section>

              {/* International News Section */}
              <section className="mb-5 bg-white p-3 rounded">
                <SectionHeader title="International News" />
                <div className="grid grid-cols-4 gap-2.5">
                  {internationalNews.map((video) => (
                    <VideoCard key={video.id} video={video} size="small" />
                  ))}
                </div>
              </section>

              {/* Bollywood Section */}
              <section className="mb-5 bg-white p-3 rounded">
                <SectionHeader title="Bollywood" />
                <div className="grid grid-cols-4 gap-2.5">
                  {bollywoodVideos.map((video) => (
                    <VideoCard key={video.id} video={video} size="small" />
                  ))}
                </div>
              </section>

              {/* Featured Videos Section */}
              <section className="mb-5 bg-white p-3 rounded">
                <SectionHeader title="Featured Videos" />
                <div className="grid grid-cols-4 gap-2.5">
                  {topVideos.slice(0, 4).map((video) => (
                    <VideoCard key={video.id} video={video} size="small" />
                  ))}
                </div>
              </section>

              {/* TOI Originals Section */}
              <section className="mb-5 bg-white p-3 rounded">
                <SectionHeader title="TOI Originals" />
                <div className="grid grid-cols-4 gap-2.5">
                  {toiOriginals.map((video) => (
                    <VideoCard key={video.id} video={video} size="small" />
                  ))}
                </div>
              </section>

              {/* Entertainment Hindi Section */}
              <section className="mb-5 bg-white p-3 rounded">
                <SectionHeader title="Entertainment Hindi" />
                <div className="grid grid-cols-4 gap-2.5">
                  {bollywoodVideos.map((video) => (
                    <VideoCard key={video.id} video={video} size="small" />
                  ))}
                </div>
              </section>

              {/* TOI Newspoint Section */}
              <section className="mb-5 bg-white p-3 rounded">
                <SectionHeader title="TOI Newspoint" />
                <div className="grid grid-cols-4 gap-2.5">
                  {topVideos.slice(0, 4).map((video) => (
                    <VideoCard key={video.id} video={video} size="small" />
                  ))}
                </div>
              </section>

              {/* Health & Fitness Section */}
              <section className="mb-5 bg-white p-3 rounded">
                <SectionHeader title="Health & Fitness" />
                <div className="grid grid-cols-4 gap-2.5">
                  {healthFitness.map((video) => (
                    <VideoCard key={video.id} video={video} size="small" />
                  ))}
                </div>
              </section>

              {/* Hollywood Section */}
              <section className="mb-5 bg-white p-3 rounded">
                <SectionHeader title="Hollywood" />
                <div className="grid grid-cols-2 gap-3">
                  {hollywoodVideos.map((video) => (
                    <VideoCard key={video.id} video={video} />
                  ))}
                </div>
              </section>

              {/* Formula E Section */}
              <section className="mb-5 bg-white p-3 rounded">
                <SectionHeader title="Formula E" />
                <div className="grid grid-cols-4 gap-2.5">
                  {formulaEVideos.map((video) => (
                    <VideoCard key={video.id} video={video} size="small" />
                  ))}
                </div>
              </section>

              {/* Food Section */}
              <section className="mb-5 bg-white p-3 rounded">
                <SectionHeader title="Food" />
                <div className="grid grid-cols-4 gap-2.5">
                  {foodVideos.map((video) => (
                    <VideoCard key={video.id} video={video} size="small" />
                  ))}
                </div>
              </section>

              {/* Music Section */}
              <section className="mb-5 bg-white p-3 rounded">
                <SectionHeader title="Music" />
                <div className="grid grid-cols-2 gap-3">
                  {musicVideos.map((video) => (
                    <VideoCard key={video.id} video={video} />
                  ))}
                </div>
              </section>

              {/* Regional Videos Hindi Section */}
              <section className="mb-5 bg-white p-3 rounded">
                <div className="flex items-center gap-4 mb-3">
                  <h2 className="text-[15px] font-bold text-[#333]">Regional Videos</h2>
                  <div className="flex gap-2">
                    <button className="text-[11px] text-red-600 font-bold">Hindi</button>
                    <button className="text-[11px] text-gray-500 hover:text-red-600">Telugu</button>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  {regionalHindi.map((video) => (
                    <VideoCard key={video.id} video={video} />
                  ))}
                </div>
              </section>
            </div>

            {/* Right Sidebar */}
            <aside className="hidden lg:block w-[280px] flex-shrink-0">
              {/* Advertisement */}
              <div className="bg-white p-3 rounded mb-4">
                <p className="text-[9px] text-gray-400 text-center mb-2">Advertisement</p>
                <div className="bg-gradient-to-br from-blue-900 to-blue-700 p-4 rounded text-white text-center">
                  <Image src="https://picsum.photos/seed/macbook/250/150" alt="MacBook Air" width={250} height={150} className="rounded mb-2" />
                  <p className="text-[11px] font-bold">MacBook Air</p>
                  <p className="text-[9px]">Smart. Speedy. Super light.</p>
                  <p className="text-[10px] text-yellow-300 mt-1">24 Month No Cost EMI at ₹4163/month</p>
                </div>
              </div>

              {/* Most Watched */}
              <div className="bg-white p-3 rounded mb-4">
                <h3 className="text-[13px] font-bold text-[#333] mb-3 pb-2 border-b border-gray-200">Most Watched</h3>
                <div className="space-y-2.5">
                  {topVideos.slice(0, 5).map((video, idx) => (
                    <Link key={idx} href="#" className="flex gap-2 group">
                      <span className="text-red-600 font-bold text-[13px] w-4">{idx + 1}</span>
                      <div className="flex-1">
                        <h4 className="text-[11px] text-[#333] group-hover:text-red-600 line-clamp-2 leading-tight">{video.title}</h4>
                        <span className="text-[9px] text-gray-500">{video.views} views</span>
                      </div>
                    </Link>
                  ))}
                </div>
              </div>

              {/* Trending Tags */}
              <div className="bg-white p-3 rounded">
                <h3 className="text-[13px] font-bold text-[#333] mb-3 pb-2 border-b border-gray-200">Trending Tags</h3>
                <div className="flex flex-wrap gap-1.5">
                  {trendingTopics.map((tag, idx) => (
                    <Link key={idx} href="#" className="px-2 py-0.5 bg-gray-100 text-[10px] text-gray-700 rounded hover:bg-red-100 hover:text-red-600">
                      {tag}
                    </Link>
                  ))}
                </div>
              </div>
            </aside>
          </div>

          {/* Footer Sections */}
          <div className="mt-6 bg-white rounded p-4">
            <HotOnWebSection />
            <TrendingTopicsSection />
            <PopularCategoriesSection />
            <TrendingVideosSection />
          </div>
        </div>
      </main>

      <Footer />
      </div>
    </div>
  );
}

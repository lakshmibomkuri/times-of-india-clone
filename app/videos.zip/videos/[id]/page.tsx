"use client";

import { Header } from "@/components/toi/header";
import { Footer } from "@/components/toi/footer";
import Image from "next/image";
import { Play, Share2, ThumbsUp, ThumbsDown, Clock, Eye, ChevronRight } from "lucide-react";

const video = {
  id: 1,
  title: "'Vande Mataram' Chants Echo As Indian Diaspora Welcomes PM Modi In Oman",
  description: "Prime Minister Narendra Modi was accorded a warm welcome by the Indian community in Muscat, Oman, where large crowds gathered at his hotel waving Indian flags and chanting patriotic slogans. PM Modi interacted with members of the diaspora and witnessed cultural performances organised in his honour.",
  duration: "08:22",
  views: "351.5K",
  date: "Jan 20, 2026",
  category: "News",
  thumbnail: "https://picsum.photos/seed/mainvid/1200/675",
  likes: 12500,
  dislikes: 234
};

const relatedVideos = [
  { id: 2, title: "Bangladesh Leader's Seven Sisters Remark Triggers Diplomatic Row", duration: "05:05", views: "1.6K", thumbnail: "https://picsum.photos/seed/rel1/200/120" },
  { id: 3, title: "US Infighting Over Venezuela Operation Escalates", duration: "09:00", views: "38", thumbnail: "https://picsum.photos/seed/rel2/200/120" },
  { id: 4, title: "Rob Reiner's Daughter Found His Body", duration: "07:18", views: "546", thumbnail: "https://picsum.photos/seed/rel3/200/120" },
  { id: 5, title: "Trump Addresses America On Venezuela", duration: "18:30", views: "2.7K", thumbnail: "https://picsum.photos/seed/rel4/200/120" },
  { id: 6, title: "Italy Refuses To Send Troops To Ukraine", duration: "09:24", views: "884", thumbnail: "https://picsum.photos/seed/rel5/200/120" },
  { id: 7, title: "Hungary PM Warns EU Against Russian Assets", duration: "06:19", views: "100", thumbnail: "https://picsum.photos/seed/rel6/200/120" },
  { id: 8, title: "Venezuela Slams Trump's Naval Blockade", duration: "08:46", views: "512", thumbnail: "https://picsum.photos/seed/rel7/200/120" },
  { id: 9, title: "PM Modi Signals Generational Shift", duration: "13:53", views: "1.2K", thumbnail: "https://picsum.photos/seed/rel8/200/120" },
];

export default function VideoPage() {
  return (
    <div className="min-h-screen bg-[#f5f5f5] overflow-x-hidden">
      {/* Left Ad Strip */}
      <div className="fixed left-0 top-0 w-[120px] h-full bg-black z-40 hidden xl:block">
        <div className="sticky top-0 h-screen flex items-center justify-center">
          <div className="text-white text-center p-3">
            <h3 className="text-sm font-bold leading-tight">Financial<br/>Backing<br/>for the<br/>Bold.</h3>
            <button className="bg-red-500 text-white text-[10px] px-3 py-1 mt-3 rounded">Apply Now</button>
          </div>
        </div>
      </div>

      {/* Right Ad Strip */}
      <div className="fixed right-0 top-0 w-[120px] h-full bg-black z-40 hidden xl:block">
        <div className="sticky top-0 h-screen flex items-center justify-center">
          <div className="text-white text-center p-3">
            <h3 className="text-sm font-bold leading-tight">Financial<br/>Backing<br/>for the<br/>Bold.</h3>
            <button className="bg-red-500 text-white text-[10px] px-3 py-1 mt-3 rounded">Apply Now</button>
          </div>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="xl:mx-[120px]">
        <Header />
        
        <main className="bg-white">
          <div className="max-w-[1200px] mx-auto px-4 py-6">
            <div className="flex gap-6">
              {/* Main Video Content */}
              <div className="flex-1">
                {/* Video Player */}
                <div className="relative aspect-video bg-black rounded-lg overflow-hidden mb-4">
                  <Image
                    src={video.thumbnail || "/placeholder.svg"}
                    alt={video.title}
                    fill
                    className="object-cover"
                  />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <button className="w-20 h-20 bg-red-600 rounded-full flex items-center justify-center hover:bg-red-700 transition-colors">
                      <Play className="w-10 h-10 text-white ml-1" fill="white" />
                    </button>
                  </div>
                  <div className="absolute bottom-4 right-4 bg-black/80 text-white text-sm px-3 py-1 rounded">
                    {video.duration}
                  </div>
                </div>

                {/* Video Info */}
                <div className="mb-6">
                  <span className="text-red-600 text-sm font-medium">{video.category}</span>
                  <h1 className="text-2xl font-bold text-gray-900 mt-1 mb-3">
                    {video.title}
                  </h1>
                  
                  <div className="flex items-center justify-between border-b border-gray-200 pb-4 mb-4">
                    <div className="flex items-center gap-4 text-sm text-gray-600">
                      <span className="flex items-center gap-1">
                        <Eye className="w-4 h-4" />
                        {video.views} views
                      </span>
                      <span className="flex items-center gap-1">
                        <Clock className="w-4 h-4" />
                        {video.date}
                      </span>
                    </div>
                    <div className="flex items-center gap-4">
                      <button className="flex items-center gap-2 text-gray-600 hover:text-red-600">
                        <ThumbsUp className="w-5 h-5" />
                        <span className="text-sm">{video.likes.toLocaleString()}</span>
                      </button>
                      <button className="flex items-center gap-2 text-gray-600 hover:text-red-600">
                        <ThumbsDown className="w-5 h-5" />
                        <span className="text-sm">{video.dislikes}</span>
                      </button>
                      <button className="flex items-center gap-2 text-gray-600 hover:text-red-600">
                        <Share2 className="w-5 h-5" />
                        <span className="text-sm">Share</span>
                      </button>
                    </div>
                  </div>

                  <p className="text-gray-700 leading-relaxed">
                    {video.description}
                  </p>
                </div>

                {/* More Videos */}
                <div className="border-t border-gray-200 pt-6">
                  <h2 className="text-xl font-bold text-gray-900 mb-4 flex items-center gap-1">
                    More Videos <ChevronRight className="w-5 h-5" />
                  </h2>
                  <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                    {relatedVideos.slice(0, 4).map((vid) => (
                      <a key={vid.id} href={`/videos/${vid.id}`} className="group">
                        <div className="relative aspect-video rounded-lg overflow-hidden mb-2">
                          <Image
                            src={vid.thumbnail || "/placeholder.svg"}
                            alt={vid.title}
                            fill
                            className="object-cover group-hover:scale-105 transition-transform"
                          />
                          <div className="absolute bottom-1 right-1 bg-black/80 text-white text-xs px-1.5 py-0.5 rounded flex items-center gap-1">
                            <Play className="w-2 h-2" fill="white" />
                            {vid.duration}
                          </div>
                        </div>
                        <h3 className="text-sm font-medium text-gray-900 group-hover:text-red-600 line-clamp-2">
                          {vid.title}
                        </h3>
                        <p className="text-xs text-gray-500 mt-1">{vid.views} views</p>
                      </a>
                    ))}
                  </div>
                </div>
              </div>

              {/* Right Sidebar - Related Videos */}
              <aside className="hidden lg:block w-[320px] flex-shrink-0">
                <h3 className="text-lg font-bold text-gray-900 mb-4">Up Next</h3>
                <div className="space-y-4">
                  {relatedVideos.map((vid) => (
                    <a key={vid.id} href={`/videos/${vid.id}`} className="flex gap-3 group">
                      <div className="relative w-[160px] h-[90px] flex-shrink-0 rounded overflow-hidden">
                        <Image
                          src={vid.thumbnail || "/placeholder.svg"}
                          alt={vid.title}
                          fill
                          className="object-cover group-hover:scale-105 transition-transform"
                        />
                        <div className="absolute bottom-1 right-1 bg-black/80 text-white text-[10px] px-1 py-0.5 rounded flex items-center gap-0.5">
                          <Play className="w-2 h-2" fill="white" />
                          {vid.duration}
                        </div>
                      </div>
                      <div className="flex-1">
                        <h4 className="text-sm font-medium text-gray-900 group-hover:text-red-600 line-clamp-2 mb-1">
                          {vid.title}
                        </h4>
                        <p className="text-xs text-gray-500">{vid.views} views</p>
                      </div>
                    </a>
                  ))}
                </div>
              </aside>
            </div>
          </div>
        </main>

        <Footer />
      </div>
    </div>
  );
}
